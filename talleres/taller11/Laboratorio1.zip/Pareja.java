
/**
 * Clase Pareja para poder hacer una lista que tenga dos valores en sus nodos
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pareja
{
    public int vertice;
    public int peso;
    public Pareja(int v,int p) {vertice = v; peso = p;}
}

import java.util.ArrayList;
/**
 * Esta clase es una implementación de un digrafo usando listas de adyacencia
 * 
 * @author Mauricio Toro 
 * @version 1
 */
public class DigraphAL extends Graph
{
   
   public DigraphAL(int size)
   {
     
   }
   
   public void addArc(int source, int destination, int weight)
   {
     
   }
   
   public int getWeight(int source, int destination)
   {
      
   }
  
   public ArrayList<Integer> getSuccessors(int vertice)
   {
   
   }
}

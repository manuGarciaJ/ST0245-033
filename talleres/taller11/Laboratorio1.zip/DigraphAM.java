import java.util.ArrayList;
/**
 * Esta clase es una implementación de un digrafo usando matrices de adyacencia
 * 
 * @author Mauricio Toro 
 * @version 1
 */
public class DigraphAM extends Graph
{

   
   public DigraphAM(int size)
   {

   }
   
   public int getWeight(int source, int destination)
   {
    
    }
   
   public void addArc(int source, int destination, int weight)
   {
    
   }
  
   public ArrayList<Integer> getSuccessors(int vertex)
   {

   }
}
